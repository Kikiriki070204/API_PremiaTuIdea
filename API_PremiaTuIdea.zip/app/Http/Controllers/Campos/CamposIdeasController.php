<?php

namespace App\Http\Controllers\Campos;

use App\Http\Controllers\Controller;
use App\Models\Campos_Idea;
use Illuminate\Http\Request;
use App\Http\Requests\StoreCampos_IdeaRequest;
use App\Http\Requests\UpdateCampos_IdeaRequest;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class CamposIdeasController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Campos_Idea $campos_Idea)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Campos_Idea $campos_Idea)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Campos_Idea $campos_Idea)
    {
        //
    }
}
