<?php

namespace App\Http\Controllers\Periodos;

use App\Http\Controllers\Controller;
use App\Models\UsuariosPeriodo;
use Illuminate\Http\Request;
use App\Http\Requests\StoreUsuariosPeriodoRequest;
use App\Http\Requests\UpdateUsuariosPeriodoRequest;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class UsuariosPeriodosController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(UsuariosPeriodo $usuariosPeriodo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(UsuariosPeriodo $usuariosPeriodo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(UsuariosPeriodo $usuariosPeriodo)
    {
        //
    }
}
