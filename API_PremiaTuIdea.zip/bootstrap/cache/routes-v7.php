<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sanctum.csrf-cookie',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/health-check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.healthCheck',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/execute-solution' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.executeSolution',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/update-config' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.updateConfig',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cFE7PVRfjrslj1xQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/test' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6KE3KMYysi2QNekD',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/meplus' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ekaI23Gh2AHM5Vcq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/verifyToken' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2Cd5nCSCqzoWKbvH',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/users/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nTTHRXaWe5Q2Aqzr',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/users/usuariosAll' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::D9NCl988pLYpOa4u',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/users/colaboradores' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bIqMkvefGUhIKVzW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/users/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0OmUKdghtzFsP38u',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/users/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::No4nysNXt5kpxXOj',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/users/nombre' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yA3j0u5sbzDL2qj9',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/ideass/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YLyuh19OT5lShSiZ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/ideass/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::J3NbZXYNTBbMnyoa',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/ideass/userIdeas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nWPacbVIkGaxIkdo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/ideass/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NPyBBO96r8zYlmvr',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/ideass/puntos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::g29YVgZTSijW55UH',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/ideass/titulo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SeckCz5NKQfMzE7O',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/ideass/ideascontables' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YaKCgYVoOX321XaA',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/ideass/ahorrocontable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wyiASe7zkHQfUF1g',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/ideass/puntoscontalbes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CRpfudq9IVHIeGLM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/ideass/ahorronocontable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::m8Xt1QrccaAXpMmo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/ideass/ideasnocontables' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5XiFYn1ojyn8nUrW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/ideasimagenes/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3u84oom5xBp01xcc',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/ideasimagenes/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::v04q2ZRLia2KKQyI',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/equipos/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vfp3dBPqIuHgmuG8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/equipos/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::F46TDb0VX2lqZq1z',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/equipos/equipoIdea' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VyQXbuTd7Wz8C0XI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/equipos/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xkfMWNMyoMmOmiyr',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/actividades/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SCIpdpVooDBLzkX0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/actividades/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9CquInUXiTy4TOEc',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/actividades/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yS1ml3YklRB2TOMW',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/roles/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3dUk4pJN5R99xxJM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/roles/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::R6asUvPMyGiSZ5tC',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/roles/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::m1mNghtGL3x43Mrk',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/areas/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bTCDRDgdGPinivLA',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/areas/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::crf1r2XL9QzppoTJ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/areas/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eJZSGmOsHnNIBlex',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/departamentos/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xWiyJ4hytRzXe8o6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/departamentos/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nF3RtMGQI0iOlxOc',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/departamentos/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RiDI8ywXTaEJWmNT',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/productos/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6JejLZMg71YU3lei',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/productos/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mmTUFoHaU8pwdNsA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/productos/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HcwuxgBOiUdRKscz',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/productos/canjear' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FO7FzzbM5UGqbGDE',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/userteam/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MMAkY8hYOW9svmXD',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/userteam/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kqGpG6PKnu0sCtnm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/userteam/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Jb7BnVNIhyDhJm6o',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/estadoideas/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GUYKFH592vb16yot',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/estadoideas/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::W6PHZsKrtkcUx6TY',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/estadoideas/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0dnrOCKLJmpMReDG',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/locaciones/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yB9Oqd4ZPbemPBJY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/locaciones/area' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MFDMvjLJCIw8uUfT',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/locaciones/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NMx5ycbn7p8t26Dl',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/locaciones/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rYJAZZViuXd0UtNf',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/estadoactividades/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kSAUa7UqAT8NtPp1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/estadoactividades/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ougT8pPg74PZXqMb',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/estadoactividades/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dpPYFQ2LoPAabRNS',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/usuariopremios/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XI4fOoXBgzFToRRn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/usuariopremios/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dqpWLuvI62vPMdxp',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/usuariopremios/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HuugYvuIxwVVwKqJ',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/estado/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ty4XuZWm5xx0xXFG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/estado/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VU7Fp9BWJLMNDg2L',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/estado/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vKfFwXI7dzZQNzQq',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/campos/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9HhVo9NT4X6teUOm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/campos/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sF8ugnBIVnV9CvHU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/campos/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EQgVhoanyj3MXYCk',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/historial/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8UTJnpUdoWwQuDhz',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/historial/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XnguekOHGhRr8iK5',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/historial/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kfI9n1PdPULrhfoE',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JqK1Lfl1LVNA4eRi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/api/(?|us(?|er(?|s/(?|colaboradoresnew/([^/]++)(*:55)|show/([0-9]+)(*:75)|delete/([0-9]+)(*:97))|team/(?|show/([0-9]+)(*:126)|delete/([0-9]+)(*:149)))|uariopremios/(?|show/([0-9]+)(*:188)|delete/([0-9]+)(*:211)))|ideas(?|s/(?|i(?|mages/([^/]++)(*:252)|deasAll(?:/([0-9]+))?(*:281))|user(?|IdeasImplementadas/([^/]++)(*:324)|ideasall(?:/([0-9]+))?(*:354))|show/([0-9]+)(*:376)|delete/([0-9]+)(*:399))|imagenes/(?|show/([0-9]+)(*:433)|delete/([0-9]+)(*:456)))|e(?|quipos/(?|show/([0-9]+)(*:493)|delete/([0-9]+)(*:516))|stado(?|ideas/(?|show/([0-9]+)(*:555)|delete/([0-9]+)(*:578))|actividades/(?|show/([0-9]+)(*:615)|delete/([0-9]+)(*:638))|/(?|show/([0-9]+)(*:664)|delete/([0-9]+)(*:687))))|a(?|ctividades/(?|show/([0-9]+)(*:729)|ideaActividades/([^/]++)(*:761)|delete/([0-9]+)(*:784))|reas/(?|show/([0-9]+)(*:814)|delete/([0-9]+)(*:837)))|roles/(?|show/([^/]++)(*:869)|delete/([^/]++)(*:892))|departamentos/(?|show/([0-9]+)(*:931)|delete/([0-9]+)(*:954))|productos/(?|show/([0-9]+)(*:989)|delete/([0-9]+)(*:1012))|locaciones/(?|show/([0-9]+)(*:1049)|delete/([0-9]+)(*:1073))|campos/(?|monetario/([0-9]+)(*:1111)|show/([0-9]+)(*:1133)|delete/([0-9]+)(*:1157))|historial/(?|show/([0-9]+)(*:1193)|delete/([0-9]+)(*:1217))))/?$}sDu',
    ),
    3 => 
    array (
      55 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QDAcS4WZuAbNmk20',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      75 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::W6BuzcMofMxPornE',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      97 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uNBr63RPoYh0ARWy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      126 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lFDZoDQ22iCHIGpJ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      149 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::j75qRCbClrRqmDTf',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      188 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LcRvtzbO5HSHYeNr',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      211 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Y1Qwt4DKwK6HxPOR',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      252 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qPow5LbsMEV9dCKi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      281 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RI6XlPEN4KQRjMpG',
            'estatus' => NULL,
          ),
          1 => 
          array (
            0 => 'estatus',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      324 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ILJjM864kayzG2dm',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      354 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AAOEChs0QTKmva6q',
            'estatus' => NULL,
          ),
          1 => 
          array (
            0 => 'estatus',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      376 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::K1emCLUs7EM1c5zw',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      399 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::L2GmA0b8Dld6Enqi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      433 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::z1HRjP60ppE5zK3N',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      456 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::atL4FeZi93wGGpj2',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      493 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IfuZra4t7WVJnRlz',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      516 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qqyFBp0Esui12AQw',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      555 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cY54vNZXAIxRyr7h',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      578 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cbjB9wI81XU0wUcl',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      615 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OGaruMPZdjFkRwKL',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      638 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::t8Gd5yx1wyo0Wkmn',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      664 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tlgnfCIlJxzl7GII',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      687 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1qp4zG3N9xiy03Nr',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      729 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::T5ki4SNfrnXT3bGm',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      761 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tynxrm2r0GrqZDkP',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      784 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::B15iljToJkxTeyjd',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      814 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CTbwe8dsiEo5aamI',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      837 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lH4oL6V40Slh1xQl',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      869 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jVwPWnppBDyH3B3i',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      892 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aemTJpFR8acBsmh0',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      931 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2jhUh0Ru5q7UdZw7',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      954 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EstmkSA601vkmXbk',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      989 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::heVnLqEE8LpFD0dD',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1012 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QM4xlzNRU33IJJqG',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1049 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::db48bmfFRmzjO6cV',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1073 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3y3Gt54E48Dv0Ppx',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1111 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::27dF07o9XxaoK8vR',
          ),
          1 => 
          array (
            0 => 'num',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1133 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OqkvCsbRCnivI82K',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1157 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2m9t7MDg41IAAgnZ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1193 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lGoggXVn1aLVcVrJ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1217 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IfbuL3zyh8ruUt9l',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'sanctum.csrf-cookie' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'sanctum.csrf-cookie',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.healthCheck' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/health-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController',
        'as' => 'ignition.healthCheck',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.executeSolution' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/execute-solution',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController',
        'as' => 'ignition.executeSolution',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.updateConfig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/update-config',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController',
        'as' => 'ignition.updateConfig',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cFE7PVRfjrslj1xQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000006870000000000000000";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::cFE7PVRfjrslj1xQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6KE3KMYysi2QNekD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/test',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:72:"function () {
    return \\response()->json([\'message\' => \'Funciona\']);
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000006860000000000000000";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::6KE3KMYysi2QNekD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'register' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/auth/register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthController@registro',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthController@registro',
        'namespace' => NULL,
        'prefix' => 'api/auth',
        'where' => 
        array (
        ),
        'as' => 'register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/auth/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthController@login',
        'namespace' => NULL,
        'prefix' => 'api/auth',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/auth/password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthController@password',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthController@password',
        'namespace' => NULL,
        'prefix' => 'api/auth',
        'where' => 
        array (
        ),
        'as' => 'password',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/auth/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthController@logout',
        'namespace' => NULL,
        'prefix' => 'api/auth',
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ekaI23Gh2AHM5Vcq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/auth/meplus',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthController@meplus',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthController@meplus',
        'namespace' => NULL,
        'prefix' => 'api/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::ekaI23Gh2AHM5Vcq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2Cd5nCSCqzoWKbvH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/auth/verifyToken',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthController@verifyToken',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthController@verifyToken',
        'namespace' => NULL,
        'prefix' => 'api/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::2Cd5nCSCqzoWKbvH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nTTHRXaWe5Q2Aqzr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/users/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@index',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@index',
        'namespace' => NULL,
        'prefix' => 'api/users',
        'where' => 
        array (
        ),
        'as' => 'generated::nTTHRXaWe5Q2Aqzr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::D9NCl988pLYpOa4u' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/users/usuariosAll',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@allUsers',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@allUsers',
        'namespace' => NULL,
        'prefix' => 'api/users',
        'where' => 
        array (
        ),
        'as' => 'generated::D9NCl988pLYpOa4u',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bIqMkvefGUhIKVzW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/users/colaboradores',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@colaboradores',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@colaboradores',
        'namespace' => NULL,
        'prefix' => 'api/users',
        'where' => 
        array (
        ),
        'as' => 'generated::bIqMkvefGUhIKVzW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QDAcS4WZuAbNmk20' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/users/colaboradoresnew/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@colaboradoresnew',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@colaboradoresnew',
        'namespace' => NULL,
        'prefix' => 'api/users',
        'where' => 
        array (
        ),
        'as' => 'generated::QDAcS4WZuAbNmk20',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0OmUKdghtzFsP38u' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/users/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@store',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@store',
        'namespace' => NULL,
        'prefix' => 'api/users',
        'where' => 
        array (
        ),
        'as' => 'generated::0OmUKdghtzFsP38u',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::W6BuzcMofMxPornE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/users/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@show',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@show',
        'namespace' => NULL,
        'prefix' => 'api/users',
        'where' => 
        array (
        ),
        'as' => 'generated::W6BuzcMofMxPornE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::No4nysNXt5kpxXOj' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/users/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@update',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@update',
        'namespace' => NULL,
        'prefix' => 'api/users',
        'where' => 
        array (
        ),
        'as' => 'generated::No4nysNXt5kpxXOj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uNBr63RPoYh0ARWy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/users/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@destroy',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/users',
        'where' => 
        array (
        ),
        'as' => 'generated::uNBr63RPoYh0ARWy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yA3j0u5sbzDL2qj9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/users/nombre',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Users\\UsersController@nombre',
        'controller' => 'App\\Http\\Controllers\\Users\\UsersController@nombre',
        'namespace' => NULL,
        'prefix' => 'api/users',
        'where' => 
        array (
        ),
        'as' => 'generated::yA3j0u5sbzDL2qj9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qPow5LbsMEV9dCKi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/ideass/images/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:553:"function ($filename) {

        $idea = \\App\\Models\\IdeasImagenes::where(\'idea_id\', $filename)->first();

        if (!$idea) {
            return \\response()->json([\'message\' => \'Imagen no encontrada\'], 404);
        }

        $filename = $idea->imagen;


        $file = \\Illuminate\\Support\\Facades\\Storage::get($filename);

        if (!$file) {
            return \\response()->json([\'message\' => \'Imagen no encontrada\', \'filename\' => $filename], 404);
        }

        return \\response($file, 200)->header(\'Content-Type\', $idea->mime_type);
    }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000069b0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => 'api/ideass',
        'where' => 
        array (
        ),
        'as' => 'generated::qPow5LbsMEV9dCKi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YLyuh19OT5lShSiZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/ideass/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\IdeasController@index',
        'controller' => 'App\\Http\\Controllers\\Ideas\\IdeasController@index',
        'namespace' => NULL,
        'prefix' => 'api/ideass',
        'where' => 
        array (
        ),
        'as' => 'generated::YLyuh19OT5lShSiZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::J3NbZXYNTBbMnyoa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/ideass/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\IdeasController@create',
        'controller' => 'App\\Http\\Controllers\\Ideas\\IdeasController@create',
        'namespace' => NULL,
        'prefix' => 'api/ideass',
        'where' => 
        array (
        ),
        'as' => 'generated::J3NbZXYNTBbMnyoa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nWPacbVIkGaxIkdo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/ideass/userIdeas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\IdeasController@userIdeas',
        'controller' => 'App\\Http\\Controllers\\Ideas\\IdeasController@userIdeas',
        'namespace' => NULL,
        'prefix' => 'api/ideass',
        'where' => 
        array (
        ),
        'as' => 'generated::nWPacbVIkGaxIkdo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ILJjM864kayzG2dm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/ideass/userIdeasImplementadas/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\IdeasController@userIdeasImplementadas',
        'controller' => 'App\\Http\\Controllers\\Ideas\\IdeasController@userIdeasImplementadas',
        'namespace' => NULL,
        'prefix' => 'api/ideass',
        'where' => 
        array (
        ),
        'as' => 'generated::ILJjM864kayzG2dm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AAOEChs0QTKmva6q' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/ideass/userideasall/{estatus?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\IdeasController@userIdeasAll',
        'controller' => 'App\\Http\\Controllers\\Ideas\\IdeasController@userIdeasAll',
        'namespace' => NULL,
        'prefix' => 'api/ideass',
        'where' => 
        array (
        ),
        'as' => 'generated::AAOEChs0QTKmva6q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'estatus' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RI6XlPEN4KQRjMpG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/ideass/ideasAll/{estatus?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\IdeasController@ideasAll',
        'controller' => 'App\\Http\\Controllers\\Ideas\\IdeasController@ideasAll',
        'namespace' => NULL,
        'prefix' => 'api/ideass',
        'where' => 
        array (
        ),
        'as' => 'generated::RI6XlPEN4KQRjMpG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'estatus' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::K1emCLUs7EM1c5zw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/ideass/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\IdeasController@show',
        'controller' => 'App\\Http\\Controllers\\Ideas\\IdeasController@show',
        'namespace' => NULL,
        'prefix' => 'api/ideass',
        'where' => 
        array (
        ),
        'as' => 'generated::K1emCLUs7EM1c5zw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NPyBBO96r8zYlmvr' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/ideass/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\IdeasController@update',
        'controller' => 'App\\Http\\Controllers\\Ideas\\IdeasController@update',
        'namespace' => NULL,
        'prefix' => 'api/ideass',
        'where' => 
        array (
        ),
        'as' => 'generated::NPyBBO96r8zYlmvr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::L2GmA0b8Dld6Enqi' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/ideass/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\IdeasController@destroy',
        'controller' => 'App\\Http\\Controllers\\Ideas\\IdeasController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/ideass',
        'where' => 
        array (
        ),
        'as' => 'generated::L2GmA0b8Dld6Enqi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::g29YVgZTSijW55UH' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/ideass/puntos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\IdeasController@puntos',
        'controller' => 'App\\Http\\Controllers\\Ideas\\IdeasController@puntos',
        'namespace' => NULL,
        'prefix' => 'api/ideass',
        'where' => 
        array (
        ),
        'as' => 'generated::g29YVgZTSijW55UH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SeckCz5NKQfMzE7O' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/ideass/titulo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\IdeasController@titulo',
        'controller' => 'App\\Http\\Controllers\\Ideas\\IdeasController@titulo',
        'namespace' => NULL,
        'prefix' => 'api/ideass',
        'where' => 
        array (
        ),
        'as' => 'generated::SeckCz5NKQfMzE7O',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YaKCgYVoOX321XaA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/ideass/ideascontables',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\IdeasController@ideascontables',
        'controller' => 'App\\Http\\Controllers\\Ideas\\IdeasController@ideascontables',
        'namespace' => NULL,
        'prefix' => 'api/ideass',
        'where' => 
        array (
        ),
        'as' => 'generated::YaKCgYVoOX321XaA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wyiASe7zkHQfUF1g' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/ideass/ahorrocontable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\IdeasController@ahorrocontable',
        'controller' => 'App\\Http\\Controllers\\Ideas\\IdeasController@ahorrocontable',
        'namespace' => NULL,
        'prefix' => 'api/ideass',
        'where' => 
        array (
        ),
        'as' => 'generated::wyiASe7zkHQfUF1g',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CRpfudq9IVHIeGLM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/ideass/puntoscontalbes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\IdeasController@puntoscontables',
        'controller' => 'App\\Http\\Controllers\\Ideas\\IdeasController@puntoscontables',
        'namespace' => NULL,
        'prefix' => 'api/ideass',
        'where' => 
        array (
        ),
        'as' => 'generated::CRpfudq9IVHIeGLM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::m8Xt1QrccaAXpMmo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/ideass/ahorronocontable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\IdeasController@ahorronocontable',
        'controller' => 'App\\Http\\Controllers\\Ideas\\IdeasController@ahorronocontable',
        'namespace' => NULL,
        'prefix' => 'api/ideass',
        'where' => 
        array (
        ),
        'as' => 'generated::m8Xt1QrccaAXpMmo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5XiFYn1ojyn8nUrW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/ideass/ideasnocontables',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\IdeasController@ideasnocontables',
        'controller' => 'App\\Http\\Controllers\\Ideas\\IdeasController@ideasnocontables',
        'namespace' => NULL,
        'prefix' => 'api/ideass',
        'where' => 
        array (
        ),
        'as' => 'generated::5XiFYn1ojyn8nUrW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3u84oom5xBp01xcc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/ideasimagenes/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\IdeasImagenesController@store',
        'controller' => 'App\\Http\\Controllers\\Ideas\\IdeasImagenesController@store',
        'namespace' => NULL,
        'prefix' => 'api/ideasimagenes',
        'where' => 
        array (
        ),
        'as' => 'generated::3u84oom5xBp01xcc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::z1HRjP60ppE5zK3N' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/ideasimagenes/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\IdeasImagenesController@show',
        'controller' => 'App\\Http\\Controllers\\Ideas\\IdeasImagenesController@show',
        'namespace' => NULL,
        'prefix' => 'api/ideasimagenes',
        'where' => 
        array (
        ),
        'as' => 'generated::z1HRjP60ppE5zK3N',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::v04q2ZRLia2KKQyI' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/ideasimagenes/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\IdeasImagenesController@update',
        'controller' => 'App\\Http\\Controllers\\Ideas\\IdeasImagenesController@update',
        'namespace' => NULL,
        'prefix' => 'api/ideasimagenes',
        'where' => 
        array (
        ),
        'as' => 'generated::v04q2ZRLia2KKQyI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::atL4FeZi93wGGpj2' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/ideasimagenes/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\IdeasImagenesController@destroy',
        'controller' => 'App\\Http\\Controllers\\Ideas\\IdeasImagenesController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/ideasimagenes',
        'where' => 
        array (
        ),
        'as' => 'generated::atL4FeZi93wGGpj2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vfp3dBPqIuHgmuG8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/equipos/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Equipo\\EquipoController@index',
        'controller' => 'App\\Http\\Controllers\\Equipo\\EquipoController@index',
        'namespace' => NULL,
        'prefix' => 'api/equipos',
        'where' => 
        array (
        ),
        'as' => 'generated::vfp3dBPqIuHgmuG8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::F46TDb0VX2lqZq1z' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/equipos/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Equipo\\EquipoController@store',
        'controller' => 'App\\Http\\Controllers\\Equipo\\EquipoController@store',
        'namespace' => NULL,
        'prefix' => 'api/equipos',
        'where' => 
        array (
        ),
        'as' => 'generated::F46TDb0VX2lqZq1z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IfuZra4t7WVJnRlz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/equipos/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Equipo\\EquipoController@show',
        'controller' => 'App\\Http\\Controllers\\Equipo\\EquipoController@show',
        'namespace' => NULL,
        'prefix' => 'api/equipos',
        'where' => 
        array (
        ),
        'as' => 'generated::IfuZra4t7WVJnRlz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VyQXbuTd7Wz8C0XI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/equipos/equipoIdea',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Equipo\\EquipoController@equipoIdea',
        'controller' => 'App\\Http\\Controllers\\Equipo\\EquipoController@equipoIdea',
        'namespace' => NULL,
        'prefix' => 'api/equipos',
        'where' => 
        array (
        ),
        'as' => 'generated::VyQXbuTd7Wz8C0XI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xkfMWNMyoMmOmiyr' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/equipos/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Equipo\\EquipoController@update',
        'controller' => 'App\\Http\\Controllers\\Equipo\\EquipoController@update',
        'namespace' => NULL,
        'prefix' => 'api/equipos',
        'where' => 
        array (
        ),
        'as' => 'generated::xkfMWNMyoMmOmiyr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qqyFBp0Esui12AQw' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/equipos/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Equipo\\EquipoController@destroy',
        'controller' => 'App\\Http\\Controllers\\Equipo\\EquipoController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/equipos',
        'where' => 
        array (
        ),
        'as' => 'generated::qqyFBp0Esui12AQw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SCIpdpVooDBLzkX0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/actividades/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Actividades\\ActividadesController@index',
        'controller' => 'App\\Http\\Controllers\\Actividades\\ActividadesController@index',
        'namespace' => NULL,
        'prefix' => 'api/actividades',
        'where' => 
        array (
        ),
        'as' => 'generated::SCIpdpVooDBLzkX0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9CquInUXiTy4TOEc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/actividades/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Actividades\\ActividadesController@store',
        'controller' => 'App\\Http\\Controllers\\Actividades\\ActividadesController@store',
        'namespace' => NULL,
        'prefix' => 'api/actividades',
        'where' => 
        array (
        ),
        'as' => 'generated::9CquInUXiTy4TOEc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::T5ki4SNfrnXT3bGm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/actividades/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Actividades\\ActividadesController@show',
        'controller' => 'App\\Http\\Controllers\\Actividades\\ActividadesController@show',
        'namespace' => NULL,
        'prefix' => 'api/actividades',
        'where' => 
        array (
        ),
        'as' => 'generated::T5ki4SNfrnXT3bGm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yS1ml3YklRB2TOMW' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/actividades/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Actividades\\ActividadesController@update',
        'controller' => 'App\\Http\\Controllers\\Actividades\\ActividadesController@update',
        'namespace' => NULL,
        'prefix' => 'api/actividades',
        'where' => 
        array (
        ),
        'as' => 'generated::yS1ml3YklRB2TOMW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tynxrm2r0GrqZDkP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/actividades/ideaActividades/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\Actividades\\ActividadesController@ideaActividades',
        'controller' => 'App\\Http\\Controllers\\Actividades\\ActividadesController@ideaActividades',
        'namespace' => NULL,
        'prefix' => 'api/actividades',
        'where' => 
        array (
        ),
        'as' => 'generated::tynxrm2r0GrqZDkP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::B15iljToJkxTeyjd' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/actividades/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Actividades\\ActividadesController@destroy',
        'controller' => 'App\\Http\\Controllers\\Actividades\\ActividadesController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/actividades',
        'where' => 
        array (
        ),
        'as' => 'generated::B15iljToJkxTeyjd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3dUk4pJN5R99xxJM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/roles/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RolesController@index',
        'controller' => 'App\\Http\\Controllers\\Auth\\RolesController@index',
        'namespace' => NULL,
        'prefix' => 'api/roles',
        'where' => 
        array (
        ),
        'as' => 'generated::3dUk4pJN5R99xxJM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::R6asUvPMyGiSZ5tC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/roles/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RolesController@store',
        'controller' => 'App\\Http\\Controllers\\Auth\\RolesController@store',
        'namespace' => NULL,
        'prefix' => 'api/roles',
        'where' => 
        array (
        ),
        'as' => 'generated::R6asUvPMyGiSZ5tC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jVwPWnppBDyH3B3i' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/roles/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RolesController@show',
        'controller' => 'App\\Http\\Controllers\\Auth\\RolesController@show',
        'namespace' => NULL,
        'prefix' => 'api/roles',
        'where' => 
        array (
        ),
        'as' => 'generated::jVwPWnppBDyH3B3i',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::m1mNghtGL3x43Mrk' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/roles/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RolesController@update',
        'controller' => 'App\\Http\\Controllers\\Auth\\RolesController@update',
        'namespace' => NULL,
        'prefix' => 'api/roles',
        'where' => 
        array (
        ),
        'as' => 'generated::m1mNghtGL3x43Mrk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aemTJpFR8acBsmh0' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/roles/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RolesController@destroy',
        'controller' => 'App\\Http\\Controllers\\Auth\\RolesController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/roles',
        'where' => 
        array (
        ),
        'as' => 'generated::aemTJpFR8acBsmh0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bTCDRDgdGPinivLA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/areas/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Area\\AreaController@index',
        'controller' => 'App\\Http\\Controllers\\Area\\AreaController@index',
        'namespace' => NULL,
        'prefix' => 'api/areas',
        'where' => 
        array (
        ),
        'as' => 'generated::bTCDRDgdGPinivLA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::crf1r2XL9QzppoTJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/areas/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\Area\\AreaController@store',
        'controller' => 'App\\Http\\Controllers\\Area\\AreaController@store',
        'namespace' => NULL,
        'prefix' => 'api/areas',
        'where' => 
        array (
        ),
        'as' => 'generated::crf1r2XL9QzppoTJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CTbwe8dsiEo5aamI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/areas/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\Area\\AreaController@show',
        'controller' => 'App\\Http\\Controllers\\Area\\AreaController@show',
        'namespace' => NULL,
        'prefix' => 'api/areas',
        'where' => 
        array (
        ),
        'as' => 'generated::CTbwe8dsiEo5aamI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eJZSGmOsHnNIBlex' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/areas/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\Area\\AreaController@update',
        'controller' => 'App\\Http\\Controllers\\Area\\AreaController@update',
        'namespace' => NULL,
        'prefix' => 'api/areas',
        'where' => 
        array (
        ),
        'as' => 'generated::eJZSGmOsHnNIBlex',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lH4oL6V40Slh1xQl' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/areas/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\Area\\AreaController@destroy',
        'controller' => 'App\\Http\\Controllers\\Area\\AreaController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/areas',
        'where' => 
        array (
        ),
        'as' => 'generated::lH4oL6V40Slh1xQl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xWiyJ4hytRzXe8o6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/departamentos/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Departamento\\DepartamentoController@index',
        'controller' => 'App\\Http\\Controllers\\Departamento\\DepartamentoController@index',
        'namespace' => NULL,
        'prefix' => 'api/departamentos',
        'where' => 
        array (
        ),
        'as' => 'generated::xWiyJ4hytRzXe8o6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nF3RtMGQI0iOlxOc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/departamentos/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Departamento\\DepartamentoController@store',
        'controller' => 'App\\Http\\Controllers\\Departamento\\DepartamentoController@store',
        'namespace' => NULL,
        'prefix' => 'api/departamentos',
        'where' => 
        array (
        ),
        'as' => 'generated::nF3RtMGQI0iOlxOc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2jhUh0Ru5q7UdZw7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/departamentos/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Departamento\\DepartamentoController@show',
        'controller' => 'App\\Http\\Controllers\\Departamento\\DepartamentoController@show',
        'namespace' => NULL,
        'prefix' => 'api/departamentos',
        'where' => 
        array (
        ),
        'as' => 'generated::2jhUh0Ru5q7UdZw7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RiDI8ywXTaEJWmNT' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/departamentos/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Departamento\\DepartamentoController@update',
        'controller' => 'App\\Http\\Controllers\\Departamento\\DepartamentoController@update',
        'namespace' => NULL,
        'prefix' => 'api/departamentos',
        'where' => 
        array (
        ),
        'as' => 'generated::RiDI8ywXTaEJWmNT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EstmkSA601vkmXbk' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/departamentos/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Departamento\\DepartamentoController@destroy',
        'controller' => 'App\\Http\\Controllers\\Departamento\\DepartamentoController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/departamentos',
        'where' => 
        array (
        ),
        'as' => 'generated::EstmkSA601vkmXbk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6JejLZMg71YU3lei' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/productos/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Producto\\ProductoController@index',
        'controller' => 'App\\Http\\Controllers\\Producto\\ProductoController@index',
        'namespace' => NULL,
        'prefix' => 'api/productos',
        'where' => 
        array (
        ),
        'as' => 'generated::6JejLZMg71YU3lei',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mmTUFoHaU8pwdNsA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/productos/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Producto\\ProductoController@store',
        'controller' => 'App\\Http\\Controllers\\Producto\\ProductoController@store',
        'namespace' => NULL,
        'prefix' => 'api/productos',
        'where' => 
        array (
        ),
        'as' => 'generated::mmTUFoHaU8pwdNsA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::heVnLqEE8LpFD0dD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/productos/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Producto\\ProductoController@show',
        'controller' => 'App\\Http\\Controllers\\Producto\\ProductoController@show',
        'namespace' => NULL,
        'prefix' => 'api/productos',
        'where' => 
        array (
        ),
        'as' => 'generated::heVnLqEE8LpFD0dD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HcwuxgBOiUdRKscz' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/productos/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Producto\\ProductoController@update',
        'controller' => 'App\\Http\\Controllers\\Producto\\ProductoController@update',
        'namespace' => NULL,
        'prefix' => 'api/productos',
        'where' => 
        array (
        ),
        'as' => 'generated::HcwuxgBOiUdRKscz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QM4xlzNRU33IJJqG' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/productos/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Producto\\ProductoController@destroy',
        'controller' => 'App\\Http\\Controllers\\Producto\\ProductoController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/productos',
        'where' => 
        array (
        ),
        'as' => 'generated::QM4xlzNRU33IJJqG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FO7FzzbM5UGqbGDE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/productos/canjear',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Producto\\ProductoController@canjear',
        'controller' => 'App\\Http\\Controllers\\Producto\\ProductoController@canjear',
        'namespace' => NULL,
        'prefix' => 'api/productos',
        'where' => 
        array (
        ),
        'as' => 'generated::FO7FzzbM5UGqbGDE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MMAkY8hYOW9svmXD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/userteam/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Equipo\\UsuarioEquipoController@index',
        'controller' => 'App\\Http\\Controllers\\Equipo\\UsuarioEquipoController@index',
        'namespace' => NULL,
        'prefix' => 'api/userteam',
        'where' => 
        array (
        ),
        'as' => 'generated::MMAkY8hYOW9svmXD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kqGpG6PKnu0sCtnm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/userteam/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Equipo\\UsuarioEquipoController@store',
        'controller' => 'App\\Http\\Controllers\\Equipo\\UsuarioEquipoController@store',
        'namespace' => NULL,
        'prefix' => 'api/userteam',
        'where' => 
        array (
        ),
        'as' => 'generated::kqGpG6PKnu0sCtnm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lFDZoDQ22iCHIGpJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/userteam/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Equipo\\UsuarioEquipoController@show',
        'controller' => 'App\\Http\\Controllers\\Equipo\\UsuarioEquipoController@show',
        'namespace' => NULL,
        'prefix' => 'api/userteam',
        'where' => 
        array (
        ),
        'as' => 'generated::lFDZoDQ22iCHIGpJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Jb7BnVNIhyDhJm6o' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/userteam/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Equipo\\UsuarioEquipoController@update',
        'controller' => 'App\\Http\\Controllers\\Equipo\\UsuarioEquipoController@update',
        'namespace' => NULL,
        'prefix' => 'api/userteam',
        'where' => 
        array (
        ),
        'as' => 'generated::Jb7BnVNIhyDhJm6o',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::j75qRCbClrRqmDTf' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/userteam/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Equipo\\UsuarioEquipoController@destroy',
        'controller' => 'App\\Http\\Controllers\\Equipo\\UsuarioEquipoController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/userteam',
        'where' => 
        array (
        ),
        'as' => 'generated::j75qRCbClrRqmDTf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GUYKFH592vb16yot' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/estadoideas/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\EstadosIdeasController@index',
        'controller' => 'App\\Http\\Controllers\\Ideas\\EstadosIdeasController@index',
        'namespace' => NULL,
        'prefix' => 'api/estadoideas',
        'where' => 
        array (
        ),
        'as' => 'generated::GUYKFH592vb16yot',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::W6PHZsKrtkcUx6TY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/estadoideas/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\EstadosIdeasController@store',
        'controller' => 'App\\Http\\Controllers\\Ideas\\EstadosIdeasController@store',
        'namespace' => NULL,
        'prefix' => 'api/estadoideas',
        'where' => 
        array (
        ),
        'as' => 'generated::W6PHZsKrtkcUx6TY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cY54vNZXAIxRyr7h' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/estadoideas/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\EstadosIdeasController@show',
        'controller' => 'App\\Http\\Controllers\\Ideas\\EstadosIdeasController@show',
        'namespace' => NULL,
        'prefix' => 'api/estadoideas',
        'where' => 
        array (
        ),
        'as' => 'generated::cY54vNZXAIxRyr7h',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0dnrOCKLJmpMReDG' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/estadoideas/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\EstadosIdeasController@update',
        'controller' => 'App\\Http\\Controllers\\Ideas\\EstadosIdeasController@update',
        'namespace' => NULL,
        'prefix' => 'api/estadoideas',
        'where' => 
        array (
        ),
        'as' => 'generated::0dnrOCKLJmpMReDG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cbjB9wI81XU0wUcl' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/estadoideas/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\Ideas\\EstadosIdeasController@destroy',
        'controller' => 'App\\Http\\Controllers\\Ideas\\EstadosIdeasController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/estadoideas',
        'where' => 
        array (
        ),
        'as' => 'generated::cbjB9wI81XU0wUcl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yB9Oqd4ZPbemPBJY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/locaciones/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Locancion\\LocacionController@index',
        'controller' => 'App\\Http\\Controllers\\Locancion\\LocacionController@index',
        'namespace' => NULL,
        'prefix' => 'api/locaciones',
        'where' => 
        array (
        ),
        'as' => 'generated::yB9Oqd4ZPbemPBJY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MFDMvjLJCIw8uUfT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/locaciones/area',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Locancion\\LocacionController@area',
        'controller' => 'App\\Http\\Controllers\\Locancion\\LocacionController@area',
        'namespace' => NULL,
        'prefix' => 'api/locaciones',
        'where' => 
        array (
        ),
        'as' => 'generated::MFDMvjLJCIw8uUfT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NMx5ycbn7p8t26Dl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/locaciones/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\Locancion\\LocacionController@store',
        'controller' => 'App\\Http\\Controllers\\Locancion\\LocacionController@store',
        'namespace' => NULL,
        'prefix' => 'api/locaciones',
        'where' => 
        array (
        ),
        'as' => 'generated::NMx5ycbn7p8t26Dl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::db48bmfFRmzjO6cV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/locaciones/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\Locancion\\LocacionController@show',
        'controller' => 'App\\Http\\Controllers\\Locancion\\LocacionController@show',
        'namespace' => NULL,
        'prefix' => 'api/locaciones',
        'where' => 
        array (
        ),
        'as' => 'generated::db48bmfFRmzjO6cV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rYJAZZViuXd0UtNf' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/locaciones/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\Locancion\\LocacionController@update',
        'controller' => 'App\\Http\\Controllers\\Locancion\\LocacionController@update',
        'namespace' => NULL,
        'prefix' => 'api/locaciones',
        'where' => 
        array (
        ),
        'as' => 'generated::rYJAZZViuXd0UtNf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3y3Gt54E48Dv0Ppx' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/locaciones/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\Locancion\\LocacionController@destroy',
        'controller' => 'App\\Http\\Controllers\\Locancion\\LocacionController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/locaciones',
        'where' => 
        array (
        ),
        'as' => 'generated::3y3Gt54E48Dv0Ppx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kSAUa7UqAT8NtPp1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/estadoactividades/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Actividades\\EstadoActividadesController@index',
        'controller' => 'App\\Http\\Controllers\\Actividades\\EstadoActividadesController@index',
        'namespace' => NULL,
        'prefix' => 'api/estadoactividades',
        'where' => 
        array (
        ),
        'as' => 'generated::kSAUa7UqAT8NtPp1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ougT8pPg74PZXqMb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/estadoactividades/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\Actividades\\EstadoActividadesController@store',
        'controller' => 'App\\Http\\Controllers\\Actividades\\EstadoActividadesController@store',
        'namespace' => NULL,
        'prefix' => 'api/estadoactividades',
        'where' => 
        array (
        ),
        'as' => 'generated::ougT8pPg74PZXqMb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OGaruMPZdjFkRwKL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/estadoactividades/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\Actividades\\EstadoActividadesController@show',
        'controller' => 'App\\Http\\Controllers\\Actividades\\EstadoActividadesController@show',
        'namespace' => NULL,
        'prefix' => 'api/estadoactividades',
        'where' => 
        array (
        ),
        'as' => 'generated::OGaruMPZdjFkRwKL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dpPYFQ2LoPAabRNS' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/estadoactividades/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\Actividades\\EstadoActividadesController@update',
        'controller' => 'App\\Http\\Controllers\\Actividades\\EstadoActividadesController@update',
        'namespace' => NULL,
        'prefix' => 'api/estadoactividades',
        'where' => 
        array (
        ),
        'as' => 'generated::dpPYFQ2LoPAabRNS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::t8Gd5yx1wyo0Wkmn' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/estadoactividades/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\Actividades\\EstadoActividadesController@destroy',
        'controller' => 'App\\Http\\Controllers\\Actividades\\EstadoActividadesController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/estadoactividades',
        'where' => 
        array (
        ),
        'as' => 'generated::t8Gd5yx1wyo0Wkmn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XI4fOoXBgzFToRRn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/usuariopremios/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\UsuarioPremiosController@index',
        'controller' => 'App\\Http\\Controllers\\UsuarioPremiosController@index',
        'namespace' => NULL,
        'prefix' => 'api/usuariopremios',
        'where' => 
        array (
        ),
        'as' => 'generated::XI4fOoXBgzFToRRn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dqpWLuvI62vPMdxp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/usuariopremios/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\UsuarioPremiosController@store',
        'controller' => 'App\\Http\\Controllers\\UsuarioPremiosController@store',
        'namespace' => NULL,
        'prefix' => 'api/usuariopremios',
        'where' => 
        array (
        ),
        'as' => 'generated::dqpWLuvI62vPMdxp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LcRvtzbO5HSHYeNr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/usuariopremios/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\UsuarioPremiosController@show',
        'controller' => 'App\\Http\\Controllers\\UsuarioPremiosController@show',
        'namespace' => NULL,
        'prefix' => 'api/usuariopremios',
        'where' => 
        array (
        ),
        'as' => 'generated::LcRvtzbO5HSHYeNr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HuugYvuIxwVVwKqJ' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/usuariopremios/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\UsuarioPremiosController@update',
        'controller' => 'App\\Http\\Controllers\\UsuarioPremiosController@update',
        'namespace' => NULL,
        'prefix' => 'api/usuariopremios',
        'where' => 
        array (
        ),
        'as' => 'generated::HuugYvuIxwVVwKqJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Y1Qwt4DKwK6HxPOR' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/usuariopremios/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\UsuarioPremiosController@destroy',
        'controller' => 'App\\Http\\Controllers\\UsuarioPremiosController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/usuariopremios',
        'where' => 
        array (
        ),
        'as' => 'generated::Y1Qwt4DKwK6HxPOR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ty4XuZWm5xx0xXFG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/estado/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\EstadoUsuarioPremiosController@index',
        'controller' => 'App\\Http\\Controllers\\EstadoUsuarioPremiosController@index',
        'namespace' => NULL,
        'prefix' => 'api/estado',
        'where' => 
        array (
        ),
        'as' => 'generated::ty4XuZWm5xx0xXFG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VU7Fp9BWJLMNDg2L' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/estado/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\EstadoUsuarioPremiosController@store',
        'controller' => 'App\\Http\\Controllers\\EstadoUsuarioPremiosController@store',
        'namespace' => NULL,
        'prefix' => 'api/estado',
        'where' => 
        array (
        ),
        'as' => 'generated::VU7Fp9BWJLMNDg2L',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tlgnfCIlJxzl7GII' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/estado/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\EstadoUsuarioPremiosController@show',
        'controller' => 'App\\Http\\Controllers\\EstadoUsuarioPremiosController@show',
        'namespace' => NULL,
        'prefix' => 'api/estado',
        'where' => 
        array (
        ),
        'as' => 'generated::tlgnfCIlJxzl7GII',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vKfFwXI7dzZQNzQq' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/estado/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\EstadoUsuarioPremiosController@update',
        'controller' => 'App\\Http\\Controllers\\EstadoUsuarioPremiosController@update',
        'namespace' => NULL,
        'prefix' => 'api/estado',
        'where' => 
        array (
        ),
        'as' => 'generated::vKfFwXI7dzZQNzQq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1qp4zG3N9xiy03Nr' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/estado/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'active',
          2 => 'adminstrador',
        ),
        'uses' => 'App\\Http\\Controllers\\EstadoUsuarioPremiosController@destroy',
        'controller' => 'App\\Http\\Controllers\\EstadoUsuarioPremiosController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/estado',
        'where' => 
        array (
        ),
        'as' => 'generated::1qp4zG3N9xiy03Nr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9HhVo9NT4X6teUOm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/campos/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Campos\\CamposController@index',
        'controller' => 'App\\Http\\Controllers\\Campos\\CamposController@index',
        'namespace' => NULL,
        'prefix' => 'api/campos',
        'where' => 
        array (
        ),
        'as' => 'generated::9HhVo9NT4X6teUOm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::27dF07o9XxaoK8vR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/campos/monetario/{num}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Campos\\CamposController@monetario',
        'controller' => 'App\\Http\\Controllers\\Campos\\CamposController@monetario',
        'namespace' => NULL,
        'prefix' => 'api/campos',
        'where' => 
        array (
        ),
        'as' => 'generated::27dF07o9XxaoK8vR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'num' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sF8ugnBIVnV9CvHU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/campos/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Campos\\CamposController@store',
        'controller' => 'App\\Http\\Controllers\\Campos\\CamposController@store',
        'namespace' => NULL,
        'prefix' => 'api/campos',
        'where' => 
        array (
        ),
        'as' => 'generated::sF8ugnBIVnV9CvHU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OqkvCsbRCnivI82K' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/campos/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Campos\\CamposController@show',
        'controller' => 'App\\Http\\Controllers\\Campos\\CamposController@show',
        'namespace' => NULL,
        'prefix' => 'api/campos',
        'where' => 
        array (
        ),
        'as' => 'generated::OqkvCsbRCnivI82K',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EQgVhoanyj3MXYCk' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/campos/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Campos\\CamposController@update',
        'controller' => 'App\\Http\\Controllers\\Campos\\CamposController@update',
        'namespace' => NULL,
        'prefix' => 'api/campos',
        'where' => 
        array (
        ),
        'as' => 'generated::EQgVhoanyj3MXYCk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2m9t7MDg41IAAgnZ' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/campos/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'adminstradores',
        ),
        'uses' => 'App\\Http\\Controllers\\Campos\\CamposController@destroy',
        'controller' => 'App\\Http\\Controllers\\Campos\\CamposController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/campos',
        'where' => 
        array (
        ),
        'as' => 'generated::2m9t7MDg41IAAgnZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8UTJnpUdoWwQuDhz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/historial/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Historial\\HistorialController@index',
        'controller' => 'App\\Http\\Controllers\\Historial\\HistorialController@index',
        'namespace' => NULL,
        'prefix' => 'api/historial',
        'where' => 
        array (
        ),
        'as' => 'generated::8UTJnpUdoWwQuDhz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XnguekOHGhRr8iK5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/historial/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Historial\\HistorialController@store',
        'controller' => 'App\\Http\\Controllers\\Historial\\HistorialController@store',
        'namespace' => NULL,
        'prefix' => 'api/historial',
        'where' => 
        array (
        ),
        'as' => 'generated::XnguekOHGhRr8iK5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lGoggXVn1aLVcVrJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/historial/show/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Historial\\HistorialController@show',
        'controller' => 'App\\Http\\Controllers\\Historial\\HistorialController@show',
        'namespace' => NULL,
        'prefix' => 'api/historial',
        'where' => 
        array (
        ),
        'as' => 'generated::lGoggXVn1aLVcVrJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kfI9n1PdPULrhfoE' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/historial/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'roles',
        ),
        'uses' => 'App\\Http\\Controllers\\Historial\\HistorialController@update',
        'controller' => 'App\\Http\\Controllers\\Historial\\HistorialController@update',
        'namespace' => NULL,
        'prefix' => 'api/historial',
        'where' => 
        array (
        ),
        'as' => 'generated::kfI9n1PdPULrhfoE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IfbuL3zyh8ruUt9l' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/historial/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'administadores',
        ),
        'uses' => 'App\\Http\\Controllers\\Historial\\HistorialController@destroy',
        'controller' => 'App\\Http\\Controllers\\Historial\\HistorialController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/historial',
        'where' => 
        array (
        ),
        'as' => 'generated::IfbuL3zyh8ruUt9l',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JqK1Lfl1LVNA4eRi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:43:"function () {
    return \\view(\'prueba\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000068b0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::JqK1Lfl1LVNA4eRi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
